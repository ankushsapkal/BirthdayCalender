var year;
var obj;
var dateWithDay;
  var weekday = new Array(7);
  weekday[0] = "Sunday";
  weekday[1] = "Monday";
  weekday[2] = "Tuesday";
  weekday[3] = "Wednesday";
  weekday[4] = "Thursday";
  weekday[5] = "Friday";
  weekday[6] = "Saturday";

// function is invoke on click of update button
function readJson() {
    var stringJson = document.getElementById('textArea').value;
	if(stringJson =='' || stringJson == null)
	{
		return 0;
	}
    obj = JSON.parse(stringJson);
	year = document.getElementById('year').value;
	if(year == ''){
		return 0;
	}
	var yearWiseData = obj.filter(yearFilter);
	console.log(yearWiseData);
	dateWithDay = yearWiseData.filter(findDay);
	console.log(dateWithDay);
	
	//call function for create day box.
		createDayBox();
}
function yearFilter(obj) {
	var tempyear = obj.birthday.slice(obj.birthday.length - 4);
  return tempyear == year;
}

function findDay(yearWiseData) {
	var date = new Date(yearWiseData.birthday)
	

  var n = weekday[date.getDay()];
  yearWiseData.day= n;

  return yearWiseData;
}

function createDayBox(){
	
	var weekdayCaps = new Array(7);
  weekdayCaps[0] = "SUN";
  weekdayCaps[1] = "MON";
  weekdayCaps[2] = "TUE";
  weekdayCaps[3] = "WED";
  weekdayCaps[4] = "THU";
  weekdayCaps[5] = "FRI";
  weekdayCaps[6] = "SAT";
  
  for(i=0;i<weekdayCaps.length; i++){
	  let panel = document.createElement("div");
	  let mainPanel = document.createElement("div");
	  let headingDiv = document.createElement("div");
	let bodyDiv = document.createElement("div");
	panel.className += 'col-md-2';
	mainPanel.className += 'panel panel-default';
	headingDiv.className += 'panel-heading';
	bodyDiv.className += 'panel-body';
	panel.id = 'PanelId'+i;
	bodyDiv.id = 'panelBody'+i;
	headingDiv.innerHTML = weekdayCaps[i];
	document.getElementById("weekdayList").appendChild(panel);
	document.getElementById("PanelId"+i).appendChild(mainPanel);
	mainPanel.appendChild(headingDiv);
	mainPanel.appendChild(bodyDiv);
	
	addNameInBox(i);
	
	
  }
}
  
  function addNameInBox(index){
	 
	 
  
  for(let n=0; n<dateWithDay.length; n++)
  {
	  if(weekday[index] == dateWithDay[n].day ){
		  getInitials(dateWithDay[n].name);
		   let InitialsContainer = document.createElement("div");
		   InitialsContainer.id = "initial"+n;
		   InitialsContainer.className += 'col-md-3 inetialClass';
		   InitialsContainer.style.backgroundColor = boxColor();
		   document.getElementById("panelBody"+index).appendChild(InitialsContainer);
		     document.getElementById("initial"+n).innerHTML = getInitials(dateWithDay[n].name);
		  
	  }
  }

		
}
var boxColor = function() {
	  var colorArray = ['red', 'green', 'blue','pink','purpal'];    
    var rand = colorArray[Math.floor(Math.random() * colorArray.length)];
	return rand;
}
var getInitials = function (string) {
    var names = string.split(' '),
        initials = names[0].substring(0, 1).toUpperCase();
    
    if (names.length > 1) {
        initials += names[names.length - 1].substring(0, 1).toUpperCase();
    }
    return initials;
};
